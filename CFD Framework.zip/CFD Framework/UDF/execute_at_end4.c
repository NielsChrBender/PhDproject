#include "udf.h"
#include "Parameters.h"
#include "dynamesh_tools.h"
#include "math.h"
#include "time.h"

extern void write_data_to_file(int headers);
void Process_time_step(int initial_run);
void set_parameters_for_adaptiv_step_next_step();

#ifdef STRUCT_REF
#define PRINT printf
#define thread-id-list a
#define thread-name-list b
#define abs-pressure p
#else
#define PRINT CX_Message
#endif

DEFINE_ON_DEMAND(end_of_step_print)
{
	//PRINT("Inlet Zone ID: %f Outlet zone ID: %f Plunger Zone ID: %f Plunger zone ID: %f Plunger Zone ID: %f Plunger zone ID: %f Plunger zone ID: %f", VARS.in_id, VARS.out_id, VARS.P22, VARS.P23, VARS.P26, VARS.P3, VARS.P33);
	VARS.EndOfStep = 1;
	Message0 ("\n -------------------------------------------------- ");
	Message0 ("\n ---------------- END OF TIME STEP ---------------- ");
	Message0 ("\n -------------------------------------------------- \n");
}

DEFINE_EXECUTE_AT_END(execute_at_end_udf)
{
	// Process converged time step
	//Message ("\n execute_at_end_udf run for ID: %i \n",myid);
	Process_time_step(0); //no headers not initial run
	//Message ("\n EXECUTE AT END: Flow time: %.12f, mesh time: %.12f \n",RP_Get_Real("flow-time"),DYNAMESH_CURRENT_TIME);
	Domain *d;
	real A[ND_ND];
	real p;
	real flow = 0.;
	real flow1 = 0.;
	real pmax = 0.;
	real pmin = 0.;
	face_t f;
	cell_t c;
	d = Get_Domain(1);
	Thread *t; 
	Thread *t1;
	Thread *t2;
	t = Lookup_Thread(d, VARS.in_id);
	t1 = Lookup_Thread(d, VARS.out_id);
	begin_f_loop(f,t)
	{
		flow+=F_FLUX(f,t);
	}
	end_f_loop(f,t)	
	VARS.mass_flow = flow*2*3.1415/861;
	begin_f_loop(f,t1)
	{
		flow1+=F_FLUX(f,t1);
	}
	end_f_loop(f,t1)	
	VARS.mass_flow1 = flow1*2*3.1415/861;

	thread_loop_c(t2,d)
	{
		/* Compute max, min, volume-averaged temperature */
		begin_c_loop(c,t2)
		{
			p = C_P(c,t2); /* get cell pressure */
			if (p < pmin || pmin == 0.) pmin = p;
			if (p > pmax || pmax == 0.) pmax = p;
		}
		end_c_loop(c,t2)
		printf("\n Pmin = %g Pmax = %g \n",pmin,pmax);
		VARS.Min_pressure = pmin;
		VARS.Max_pressure = pmax;
	}
}

DEFINE_ON_DEMAND(Process_initial_problem)
{
	//Process initial problem
	//Message0 ("\n Process_initial_problem run for all processes.. \n");
	Process_time_step(1); //write headers initial run
	int i;
    int a = RP_Get_List_Length("thread-id-list");
	char *name;
    for (i = 0; i < a; i++)
    {
		name = RP_Get_List_Ref_String("thread-name-list", i);
		if (strcmp(name, "ns_pressureoutlet-ns_fluid-1") == 0)
		{
			VARS.in_id = RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_pressureoutlet-ns_fluid-5") == 0)
		{
			VARS.out_id = RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_plungerface-3-ns_fluid-6") == 0)
		{
			VARS.P3 = RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_plungerface-3-ns_fluid-3") == 0)
		{
			VARS.P33 = RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_plungerface-2-ns_fluid-6") == 0)
		{
			VARS.P26= RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_plungerface-2-ns_fluid-7") == 0)
		{
			VARS.P27= RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_plungerface-2-ns_fluid-3") == 0)
		{
			VARS.P23 = RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else if (strcmp(name , "ns_plungerface-2-ns_fluid-2") == 0)
		{
			VARS.P22 = RP_Get_List_Ref_Int("thread-id-list", i);
		}
		else
		{
		}
    }
}

void Process_time_step(int initial_run)
{
	//Message ("\n write_data_to_file and set_parameters_for_adaptiv_step_next_step run for node %i .. \n",myid);
	calc_step_solution_data(initial_run); //calculate data for converged time step
	write_data_to_file(initial_run);
	set_parameters_for_adaptiv_step_next_step();
}

void set_parameters_for_adaptiv_step_next_step()
{
	/*
	double Max_step_size=1e-4;

	Max_step_size = Set_Max_step_size(calc_Max_step_size_for_valve_movement(VARS.dot_x_L,VARS.dot_x_H,VARS.x_L,VARS.x_H),Max_step_size); //max mesh movement relating to valve movement
	
	if(VARS.goto_interfaces==1 || VARS.Decrease_time_step==1) {
		Max_step_size = Set_Max_step_size(1.0e-8,Max_step_size); }

	// Reset goto signal from scheme files after use
	if(VARS.goto_interfaces>0) {
		VARS.goto_interfaces=0; }

	// Limit step size when valves are moving or both valves 'closed' 
	if(VARS.dot_x_L>0 || VARS.dot_x_H>0 || (VARS.x_L<1.5e-3 && VARS.x_H<1.5e-3))
	{
		Max_step_size = Set_Max_step_size(0.5e-5,Max_step_size);
	}
	
	// Set global vars
	
	*/
	double deltaSmax_max, deltaSmax_min, x_NearEnd, x_beginSlope, deltaSmax;
	deltaSmax_max = 5e-5; // from 0.025e-3
	deltaSmax_min = 3e-6; // from 0.008e-5
	x_NearEnd = 5e-5; 
	x_beginSlope = 0*CONST.stroke/2;
	if (VARS.x<x_beginSlope)
	{
		deltaSmax = deltaSmax_max;
	}
	/*else if (VARS.x>(CONST.stroke-x_NearEnd))
	{
		deltaSmax = deltaSmax_min;
	}*/
	else if (VARS.x>(CONST.stroke-0.1*x_NearEnd))
	{
		deltaSmax = deltaSmax_min*0.1;
	}
	else // slope region
	{
		deltaSmax = (deltaSmax_min-deltaSmax_max)/(CONST.stroke-x_beginSlope)*(VARS.x-x_beginSlope)+deltaSmax_max;
	}
	//deltaSmax = VARS.h_ideal*0.15;
	VARS.Max_step_size = CONST.alpha_h*deltaSmax/sqrt(VARS.dot_x*VARS.dot_x);
	/*if (VARS.Max_step_size>5e-5*1.5/abs(VARS.dot_x+1e-4))
	{
		VARS.Max_step_size = 5e-5*1.5/abs(VARS.dot_x+1e-4); //1e-4
	} 
	if (VARS.Max_step_size>5e-3) //7.5e-5
	{
		VARS.Max_step_size = 5e-3;
	}*/
	Message("\n Max step size: %e , deltaSmax: %e \n",VARS.Max_step_size,deltaSmax);
	// set parameters before update by scheme function (update-adaptive-step), defined in Load_udf_and_schemes.scm
	RP_Set_Real("truncation_error_tol", CONST.Truncation_error_tol);
	RP_Set_Real("min_step_size", VARS.Min_step_size);
	RP_Set_Real("max_step_size", VARS.Max_step_size);
	RP_Set_Real("min_change_step_factor", CONST.Min_change_step_factor);
	RP_Set_Real("max_change_step_factor", CONST.Max_change_step_factor);
}