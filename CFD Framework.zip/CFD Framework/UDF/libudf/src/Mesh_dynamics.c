#include "udf.h"
#include "dynamesh_tools.h"
#include "Parameters.h"
#include "math.h"
#define PI 3.141592653589793238462643383

DEFINE_PROFILE(VelocityInlet_UDF,thread,i) 
{
	face_t f;
	double time, time1, time_old, theta; //Net_force, delta_vel_x, dtime, time;
	time = RP_Get_Real("flow-time");
	theta = CONST.theta_ini + CONST.dot_theta*time;
	if (VARS.x < 2.585e-3 && VARS.HPV == 1) //> 0
	{
		VARS.HPV = 1;
		VARS.LPV = 0;
	}
	else 
	{
		VARS.HPV = 0;
		VARS.LPV = 1;
	}
	VARS.x_p = cos(theta)*CONST.r_e+CONST.r_e;
	VARS.dot_x_p = -sin(theta)*CONST.r_e*CONST.dot_theta;
	VARS.V = CONST.V0 + VARS.x_p*CONST.A_cp + VARS.HPV*VARS.x*CONST.A_cv - VARS.LPV*VARS.x*CONST.A_cv;
	VARS.dot_p_c = CONST.beta0/VARS.V*(VARS.HPV*VARS.mass_flow - VARS.LPV*VARS.mass_flow - VARS.dot_x_p*CONST.A_cp);
	VARS.p_c = 0*VARS.dot_p_c*RP_Get_Real("physical-time-step") + VARS.p_c; 

	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*VARS.p_c + VARS.LPV*VARS.p_c; //VARS.dot_x_p*CONST.A_cp*CONST.rhoF0; // times sin(theta) VARS.HPV*349.5e5 + VARS.LPV*CONST.p_L       p_L to p_c
		}
	end_f_loop(f, thread)
}

DEFINE_PROFILE(PressureProfile,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*CONST.p_H + VARS.LPV*CONST.p_H; // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile0,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(VARS.p_c) + VARS.LPV*(VARS.p_c); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile05,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(CONST.p_L+0.05e5) + VARS.LPV*(CONST.p_H); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile1,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(CONST.p_L+0.1e5) + VARS.LPV*(CONST.p_H); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile2,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(CONST.p_L+0.2e5) + VARS.LPV*(CONST.p_H); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile3,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(CONST.p_L+0.3e5) + VARS.LPV*(CONST.p_H); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile4,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(CONST.p_L+0.38e5) + VARS.LPV*(CONST.p_H-0.1e5); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}
DEFINE_PROFILE(PressureProfile5,thread,i) 
{
	face_t f;
	begin_f_loop(f, thread)
		{
			F_PROFILE(f, thread, i) = VARS.HPV*(CONST.p_L+0.5e5) + VARS.LPV*(CONST.p_H-CONST.deltap-0.1e5); // times sin(theta) 				p_C to p_H
		}
	end_f_loop(f, thread)
}

DEFINE_CG_MOTION(PlungerMovement,dt,vel,omega,time,dtime)
{
double time1;	
	if ((time-VARS.time_previous_calc)>0.1*dtime) //do calculation once per new timestep (function called several times, one per moving zone..)
	{
		// Calculate velocity and position
		if (VARS.HPV == 1)
		{
			VARS.dot_i = (CONST.U-VARS.i*CONST.R-CONST.k_act*VARS.dot_x)/CONST.L;
			VARS.i = VARS.dot_i*dtime+VARS.i;
			VARS.F_act = 80;//VARS.i*CONST.k_act;
			time1 = time;
		}
		else 
		{
			VARS.dot_i = 0;
			VARS.i = 0;
			VARS.F_act = -1*80;
		}
		if (VARS.x < 0)
		{
			VARS.ddot_x = 0;
			VARS.dot_x = 0;
			VARS.x = 0;
		}
		else if (VARS.LPV == 1)
		{
			VARS.p_c = VARS.p_c;// CONST.p_H-CONST.deltap+(2*CONST.deltap); //(1-exp(-1e2*(time-time1)))*
			VARS.ddot_x = (VARS.F_act - VARS.F_fluid - VARS.dot_x*4.3 - CONST.spring - CONST.k_s*VARS.x)/CONST.mass; // (1-exp(-5e3*time)) 1*(1-exp(-5e3*time)) designed to slowly activate spring 1*(1-exp(-5e3*time))*
			//VARS.ddot_x = (VARS.F_act)/CONST.mass;
			VARS.dot_x = VARS.ddot_x*dtime + VARS.dot_x;
			VARS.x = VARS.dot_x*dtime + VARS.x;
		}
		else if (VARS.x > 2.595e-3)
		{
			VARS.ddot_x = 0;
			VARS.dot_x = 0;
			VARS.x = 2.4955e-3;
		}
		else if (time > 0.0)
		{
			VARS.ddot_x = (VARS.F_act - VARS.F_fluid - VARS.dot_x*4.3 - CONST.spring - CONST.k_s*(VARS.x))/CONST.mass; //  1*(1-exp(-5e3*time)) designed to slowly activate spring 1*(1-exp(-5e3*time))*
			//VARS.ddot_x = VARS.F_act/CONST.mass;
			VARS.dot_x = VARS.ddot_x*dtime + VARS.dot_x;
			//VARS.dot_x = 1e-3;
			VARS.x = VARS.dot_x*dtime + VARS.x;
		}	
		else 
		{
			VARS.ddot_x = 0;//(VARS.F_act - VARS.F_fluid - VARS.dot_x*4.3 - CONST.spring - CONST.k_s*VARS.x)/CONST.mass; //  1*(1-exp(-5e3*time)) designed to slowly activate spring 1*(1-exp(-5e3*time))*
			VARS.dot_x = 0;//VARS.ddot_x*dtime + VARS.dot_x;
			VARS.x = VARS.dot_x*dtime + VARS.x;
		}
		//Message("\n Mesh info, DT_CG(dt)[0]=%.15f , DT_CG(dt)[1]=%.15f , DT_CG(dt)[2]=%.15f , \n DT_VEL_CG(dt)[0]=%.15f , DT_VEL_CG(dt)[1]=%.15f , DT_VEL_CG(dt)[2]=%.15f \n",DT_CG(dt)[0],DT_CG(dt)[1],DT_CG(dt)[2],DT_VEL_CG(dt)[0],DT_VEL_CG(dt)[1],DT_VEL_CG(dt)[2]);
		//Message("\n Running vel control, x=%.15f , dot_x=%.15f \n",VARS.x,VARS.dot_x);
		VARS.time_previous_calc = time; 
		vel[0] = -VARS.dot_x; 
	}
	else
	{
		vel[0] = -VARS.dot_x; // Data from first zone reused
		//Message("\n Other zone vel[0]: %.15f \n",VARS.dot_x);
	} 
}

DEFINE_DYNAMIC_ZONE_PROPERTY(LayeringHeightUDF, dt, height)
{
	if (VARS.x > (0.7*VARS.h_ideal+VARS.x_accu))
	{
		VARS.h_old = VARS.h_ideal;
		VARS.h = VARS.h_old/(CONST.k)+0.3*VARS.h_ideal;
		VARS.x_accu = VARS.x;
		VARS.count = 1+VARS.count;
		*height = VARS.h_old/(CONST.k);
	}
	else
	{
		VARS.h =  VARS.h_old/(CONST.k)+0.3*VARS.h_ideal-(VARS.x-VARS.x_accu);
		*height = VARS.h_old/(CONST.k);
	}
	if (VARS.x > 2.46e-3)
	{
		*height = 5e-5;
	}
	else if (VARS.x > 2.49e-3)
	{
		*height = 1e-5;
	}
	else
	{
		*height = 0*((1e-5-1e-4)/(CONST.stroke-0))*(VARS.x)+1e-4;
	}
	VARS.h_ideal = *height;
}

DEFINE_PROPERTY(cell_viscosity,c,t)
{
	real mu_lam;
	real p, p_operating;
	real temp, alpha;
	temp = 40+273.15; // define the temperature you want to investigate
	//temp = C_T(c, t);
	p_operating = RP_Get_Real ("operating-pressure");
	p = (p_operating + C_P(c, t)); 
	alpha = 1/(334+3.2557*(temp-273.15)+(0.026266+0.000315*(temp-273.15))*p/1e5)*1e-5;
	mu_lam = 0.0000633361*exp(879.7742/((temp)-177.7865))*exp(alpha*p); 
	//mu_lam = CONST.mu0*exp(VARS.alpha*p);  0.0000633361 & 4.1595e-05 for 46 & 32 cSt resp
 return mu_lam;
}

DEFINE_PROPERTY(superfluid_density,c,t)
{
	real rho;
	real p, dp; 
	real p_operating;
    
    p_operating = RP_Get_Real ("operating-pressure");
	p = p_operating + C_P(c, t);
	rho = (CONST.rhoF0*(1-CONST.eps)+CONST.rhoA0*CONST.eps)/((1-CONST.eps)*pow(1+(CONST.m*(p-CONST.p0))/CONST.beta0, -1/CONST.m)+CONST.eps*pow(CONST.p0/p, 1/CONST.kappa));
	//dp = p-CONST.p0;
    //rho = CONST.rhoF0/(1-dp/CONST.beta0);//;
 return rho;
}

DEFINE_PROPERTY(sound_speed,c,t)
{
	real a;
	real rho, beta;
	real p, dp, p_operating;
	  
	p_operating = RP_Get_Real ("operating-pressure");
	p = p_operating + C_P(c, t); 
	dp = p-CONST.p0;
	//rho = CONST.rhoF0/(1-dp/CONST.beta0);
	rho = (CONST.rhoF0*(1-CONST.eps)+CONST.rhoA0*CONST.eps)/((1-CONST.eps)*pow(1+(CONST.m*(p-CONST.p0))/CONST.beta0, -1/CONST.m)+CONST.eps*pow(CONST.p0/p, 1/CONST.kappa));
	beta = ((1-CONST.eps)*pow(1+(CONST.m*(p-CONST.p0))/CONST.beta0, -1/CONST.m)+CONST.eps*pow(CONST.p0/p, 1/CONST.kappa))/((1-CONST.eps)/CONST.beta0*pow(1+(CONST.m*(p-CONST.p0))/CONST.beta0, -1-1/CONST.m)+CONST.eps/(CONST.kappa*CONST.p0)*pow(CONST.p0/p, 1+1/CONST.kappa));
	a = sqrt(beta/rho);
    //a = (1-dp/CONST.beta0)*sqrt(CONST.beta0/CONST.rhoF0); 
	//a = sqrt(8000e5/861);
 return a;
}