// 
// Parameters.c
//
#include "Parameters.h"
#include "string.h"
#include "udf.h"
#include "math.h"
#define PI 3.141592653589793238462643383

Constants CONST;
Variables VARS;
output_set OUT_ARRAY[out_array_size];

char *replace_str(char *str, char *orig, char *rep);
void Write_var_to_scm_file(char* name, double value);

DEFINE_EXECUTE_ON_LOADING(initialize_parameters_func,libudf)
{
	int i,count;
	int cmp_result=1;
	char *model_dir;
	char *variation_dir;
	char *modified_dir;
	Message0 ("\n Parameters.c run for all processes.. \n");

	model_dir = RP_Get_String("model_dir");
	variation_dir = RP_Get_String("variation_dir");
	sprintf(CONST.data_dir,"%sVariations/%s/File_output/",model_dir,variation_dir);
	//Message ("\n pre replace: %s \n",CONST.data_dir);
	count=0;
	modified_dir = replace_str(CONST.data_dir, "/", "\\");
	for(count=0;count<100;count++) 
	{
		modified_dir = replace_str(modified_dir, "/", "\\");
	}
	sprintf(CONST.data_dir,"%s",modified_dir);
	//Message ("\n post replace: %s \n",CONST.data_dir);

	for(i=0;i<out_array_size;i++)
	{
		OUT_ARRAY[i].value = 0.0;  
		strcpy(OUT_ARRAY[i].name,"NOT_IN_USE");
	}
	CONST.mass = 0.019;
	CONST.MaxFlowVelocity = 7.3609; //(666/60000)/(3.1415926*((34e-3)^2-(26e-3)^2)); // V = Q/A
	CONST.dot_theta = 800/60*2*PI; //RPM*2pi/60
	CONST.theta_ini = 30*PI/180;
	CONST.stroke = 2.5e-3;
	CONST.k_s = 2220;
	CONST.spring = 31;
	CONST.L = 0.77e-3;
	CONST.k_act = 5;
	CONST.k = 1.0371;
	CONST.R = 2.6;
	CONST.U = 50;//42.18;
	CONST.p_L = 5e5;
	CONST.p_H = 350e5;
	CONST.deltap = 0.6e5;
	VARS.HPV = 1;
	VARS.LPV = 0;
	// step
	CONST.Truncation_error_tol = 0.01; Write_var_to_scm_file("truncation_error_tol", CONST.Truncation_error_tol); //0.0001 0.001
	CONST.Min_change_step_factor = 0.5; Write_var_to_scm_file("min_change_step_factor", CONST.Min_change_step_factor);
	CONST.Max_change_step_factor = 5; Write_var_to_scm_file("max_change_step_factor", CONST.Max_change_step_factor); //5.0
	// Fluid parameters
	VARS.alpha = 2.1e-8;
	CONST.alpha_h = 0.5;
	CONST.beta0 = 15500e5;
	CONST.kappa = 1.4;
	CONST.eps = 0.005;
	CONST.m = 11.4;
	CONST.mu0 = 0.0221; //  0.1257  0.0421 0.0221
	CONST.rhoF0 = 870;
	CONST.rhoA0 = 1.14;
	CONST.p0 = 1e5;
	CONST.r_e = 49.12e-3/2;
	CONST.A_cp = PI*18e-3*18e-3;
	CONST.A_cv = PI*(17.6e-3*17.6e-3+12.4e-3*12.4e-3)/2;
	CONST.V0 = 62e-6;
	// Variable parameters 
	VARS.Time = 0.0;
	VARS.Dynamic_thread_valve = NULL;
	VARS.time_previous_calc = 0.0;
	VARS.Old_time_step = 0.0;
	VARS.Old_N_ITER = 0;
	VARS.Old_elapsed_time = 0;
	VARS.first_time = 0;
	VARS.sim_time_total = 0;
	VARS.sim_time_last_step = 0;
	VARS.Number_of_iterations = 0;
	VARS.Iterations_last_step = 0;
	VARS.Size_time_step = 0;
	VARS.x = 0; // 2.4e-3
	VARS.x_old = 0.0;
	VARS.dot_x = 0.0;
	VARS.ddot_x = 0.0;
	VARS.dot_x_old = 0.0;
	VARS.F_act = 80.0; // <-- 100-800
	VARS.F_fluid = 0.0;
	VARS.EndOfStep = 1;
	VARS.dot_i = 0.0;
	VARS.i = 0.0;
	VARS.dot_p_c = 0.0;
	VARS.p_c = CONST.p_L;
	VARS.h_ideal = 9.52e-5;
	VARS.h_old = 1e-4;
	VARS.x_accu = 0;
	VARS.count = 1; 
	VARS.x_p = cos(CONST.theta_ini)*CONST.r_e+CONST.r_e;
	VARS.dot_x_p = -sin(CONST.theta_ini)*CONST.r_e*CONST.dot_theta;
	VARS.mass_flow = VARS.dot_x_p*CONST.A_cp/(2*PI);
	VARS.mass_flow1 = VARS.dot_x_p*CONST.A_cp/(2*PI);
	VARS.Min_step_size = 1.0e-8; Write_var_to_scm_file("min_step_size", VARS.Min_step_size); //1.0e-8
	VARS.Max_step_size = 1.0e-3; Write_var_to_scm_file("max_step_size", VARS.Max_step_size); //1e-4
	VARS.in_id = 35;
	VARS.out_id = 31;
	VARS.P22 = 18;
	VARS.P23 = 19;
	VARS.P26 = 20;
	VARS.P27 = 30;
	VARS.P3 = 31;
	VARS.P33 = 32;

}

char *replace_str(char *str, char *orig, char *rep)
{
  static char buffer[4096];
  char *p;

  if(!(p = strstr(str, orig)))  // Is 'orig' even in 'str'?
    return str;

  strncpy(buffer, str, p-str); // Copy characters from 'str' start to 'orig' st$
  buffer[p-str] = '\0';

  sprintf(buffer+(p-str), "%s%s", rep, p+strlen(orig));

  return buffer;
}

void Write_var_to_scm_file(char* name, double value)
{
	FILE *fid;
	// file output
	fid = fopen("Temp_variable_values_from_udf.scm", "a");
	fprintf(fid,"(rp-var-define '%s %f 'real #f) \n",name,value); 
	fclose(fid);
}