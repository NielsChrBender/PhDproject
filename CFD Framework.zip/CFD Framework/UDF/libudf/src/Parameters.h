//
// Parameters.h
//
#include "udf.h"
#include "dynamesh_tools.h"

#define INHERIT 0.0

typedef struct {
	double mass;
	double MaxFlowVelocity;
	double dot_theta;
	char data_dir[250];
	double Truncation_error_tol;
	double Min_change_step_factor;
	double Max_change_step_factor;
	double stroke;
	double L;
	double R;
	double U;
	double spring;
	double k;
	double k_act;
	double k_s;
	double alpha_h;
	double beta0;
	double eps;
	double kappa;
	double m;
	double mu0; 
	double rhoF0;
	double rhoA0;
	double p0;
	double theta_ini;
	double r_e;
	double A_cp;
	double A_cv;
	double V0;
	double p_H;
	double p_L;
	double deltap;

} Constants;

extern Constants CONST;

typedef struct {
	char name[64];
	double value;
} output_set;

#define out_array_size 100
extern output_set OUT_ARRAY[out_array_size];

typedef struct {
	double Time;
	Dynamic_Thread* Dynamic_thread_valve;
	double time_previous_calc;
	double Old_time_step;
	int Old_N_ITER;
	double Old_elapsed_time;
	double first_time;
	double sim_time_total;
	double sim_time_last_step;
	double Number_of_iterations;
	double Iterations_last_step;
	double Size_time_step;
	double x;
	double x_old;
	double dot_x;
	double ddot_x;
	double dot_x_old;
	double F_act;
	double F_fluid;
	double M_fluid;
	double i;
	double dot_i;
	int EndOfStep;
	double Min_step_size;
	double Max_step_size;
	double x_p;
	double dot_x_p;
	double V;
	double dot_p_c;
	double p_c;
	double mass_flow;
	double mass_flow1;
	int HPV;
	int LPV;
	double p_gap;
	double alpha;
	double h_ideal;
	double h_old;
	double x_accu;
	double count;
	double h;
	double Min_pressure;
	double Max_pressure;
	double in_id;
	double out_id;
	double P22;
	double P23;
	double P26;
	double P27;
	double P33;
	double P3;
} Variables;

extern Variables VARS;
