#include "udf.h"
#include "Parameters.h"

void ADD_TO_OUTPUT_ARRAY(char* name, double value, int initial_run);
void write_data_to_file(int headers);
double Face_force_x(int face_ID);
double Mass_flow_x(int face_ID);
void Calc_actuation_forces(double x_L, double x_H);

void calc_step_solution_data(int initial_run)
{	
	time_t seconds;
	double current_elapsed_time;

	VARS.Time = RP_Get_Real("flow-time");																					ADD_TO_OUTPUT_ARRAY("Time",VARS.Time,initial_run);

	// simulation info
	seconds = time(NULL); //seconds since 1970
	if(VARS.first_time==0)
	{
		VARS.first_time = (double)seconds; 
		VARS.Old_elapsed_time = (double)seconds; 
	}
	current_elapsed_time = (double)seconds; 
	VARS.sim_time_total = current_elapsed_time - VARS.first_time;															ADD_TO_OUTPUT_ARRAY("sim_time_total",VARS.sim_time_total,initial_run);
	VARS.sim_time_last_step = current_elapsed_time - VARS.Old_elapsed_time;													ADD_TO_OUTPUT_ARRAY("sim_time_last_step",VARS.sim_time_last_step,initial_run);
	VARS.Number_of_iterations =  (double)N_ITER;																			ADD_TO_OUTPUT_ARRAY("Number_of_iterations",VARS.Number_of_iterations,initial_run);
	VARS.Iterations_last_step =  (double)N_ITER - VARS.Old_N_ITER;															ADD_TO_OUTPUT_ARRAY("Iterations_last_step",VARS.Iterations_last_step,initial_run);
	VARS.Size_time_step = RP_Get_Real("physical-time-step");																ADD_TO_OUTPUT_ARRAY("Size_time_step",VARS.Size_time_step,initial_run);
	//Message ("Time step info: current_state = %i, iterations_last_step = %i , time_step = %f current_iter = %i \n",VARS.current_state,Iterations_last_step,time_step,N_ITER); 
	VARS.Old_elapsed_time = current_elapsed_time; // save for next iteration
	VARS.Old_N_ITER = (double)N_ITER;

	//if(!(VARS.Dynamic_thread_valve==NULL)) // dynamic thread pointer differs from NULL 
	//{
	//	VARS.x = -DT_CG(VARS.Dynamic_thread_valve)[0]; //pos
	//	VARS.dot_x = -DT_VEL_CG(VARS.Dynamic_thread_valve)[0]; // vel
	//}
	ADD_TO_OUTPUT_ARRAY("x [mm]",VARS.x*1e3,initial_run);
	ADD_TO_OUTPUT_ARRAY("dot_x [m/s]",VARS.dot_x,initial_run);
	ADD_TO_OUTPUT_ARRAY("ddot_x [km/s^2]",VARS.ddot_x*1e-3,initial_run);
	// HPV or LPV flow and force
	//VARS.mass_flow = Mass_flow_x(20); 
	VARS.F_fluid = Face_force_x(24) + Face_force_x(25) + Face_force_x(26) + Face_force_x(34) + Face_force_x(27);   			ADD_TO_OUTPUT_ARRAY("F_fluid",VARS.F_fluid,initial_run); ADD_TO_OUTPUT_ARRAY("F_act",VARS.F_act,initial_run);  // ADD_TO_OUTPUT_ARRAY("F_fluid",VARS.F_fluid,initial_run  Face_force_x(28) + Face_force_x(29) + Face_force_x(30) + Face_force_x(31)
	ADD_TO_OUTPUT_ARRAY("x_p",VARS.x_p*1e3,initial_run); ADD_TO_OUTPUT_ARRAY("p_c",VARS.p_c*1e-5,initial_run); ADD_TO_OUTPUT_ARRAY("dot_p_c",VARS.dot_p_c*1e-5,initial_run); ADD_TO_OUTPUT_ARRAY("Mass flow",VARS.mass_flow,initial_run); ADD_TO_OUTPUT_ARRAY("Mass flow1",VARS.mass_flow1,initial_run); 
	//Message ("DEBUG: d: %i, ID: %i, F_fluid_lpv %f \n",d,VARS.wall_zones_LPV[0],F_fluid_lpv); 
	//ADD_TO_OUTPUT_ARRAY("p_gap",VARS.p_gap*1e-5,initial_run); 
}

void ADD_TO_OUTPUT_ARRAY(char* name, double value, int initial_run)
{
	int i;
	if(initial_run==1)
	{
		for(i=0;i<out_array_size;i++)
		{
			if(strcmp(OUT_ARRAY[i].name,"NOT_IN_USE")==0) //strings equal
			{
				OUT_ARRAY[i].value = value;  
				strcpy(OUT_ARRAY[i].name,name);
				break;
			}
			if(i==(out_array_size-1))
			{
				Message ("\n WARNING!!! out_array_size not large enough!!! --------------------------\n");
			}
		}
	}
	else //find name in array and place new value
	{
		for(i=0;i<out_array_size;i++)
		{
			if(strcmp(OUT_ARRAY[i].name,name)==0) //strings equal
			{
				OUT_ARRAY[i].value = value;  
				break;
			}
			if(i==(out_array_size-1))
			{
				Message ("\n WARNING!!! corresponding name not found in out_array_size!!! --------------------------\n");
			}
		}
	}
}

void write_data_to_file(int headers)
{
	FILE *fid;	
	int i;
	char output_file[500];
	
	//sprintf(output_file,"%sAnalysis_data%i.out",CONST.data_dir,myid);
	sprintf(output_file,"%sAnalysis_data.out",CONST.data_dir);
	if(headers==1)
		fid = fopen(output_file, "w"); 
	else
	{
		fid = fopen(output_file, "a"); 
	}

	if(headers==1) //print headers
	{
		for(i=0;i<out_array_size;i++)
		{
			if(strcmp(OUT_ARRAY[i].name,"NOT_IN_USE")==0) //strings equal
			{
				fprintf(fid,"\n");
				break;
			}
			else
			{
				fprintf(fid,"%s ",OUT_ARRAY[i].name);
			}
		}
	}	
	
	// print values
	for(i=0;i<out_array_size;i++)
	{
		if(strcmp(OUT_ARRAY[i].name,"NOT_IN_USE")==0) //strings equal
		{
			fprintf(fid,"\n");
			break;
		}
		else
		{
			fprintf(fid,"%.16f ",OUT_ARRAY[i].value); 
		}
	}
	fclose(fid);
}

double Face_force_x(face_ID)
{
	// face force x-direction
	Domain *d = Get_Domain(1);
	Thread *tf;
	face_t f;
	double force[3], moment[3], CG[ND_ND];
	double total_force[3] = {0.0};
	int i;
	//for(i=0;i<N_faces;i++)
	//{
	tf = Lookup_Thread(d, face_ID); 
	//begin_f_loop(f,tf)
		//{
		NV_S (CG, =, 0.0);
		Compute_Force_And_Moment (d, tf, CG, force, moment, FALSE);
		NV_V(total_force,+=,force);
		//} 
	//end_f_loop(f,tf)
	//}
	return total_force[0]; //x-direction
}
/*
double Mass_flow_x(face_ID)
{
	double flow, flow_tot;
	Domain *d; 
	face_t f;
	d = Get_Domain(1);
	Thread *t;
	t = Lookup_Thread(d, face_ID);
	flow = 0;
	begin_f_loop(f,t)
	{
		flow+=F_FLUX(f,t);
	}
	end_f_loop(f,t)	
	flow_tot = flow;
	return flow_tot;
}

double Face_shear_x(face_ID)
{
	// wall shear forces 
	Domain *d = Get_Domain(1); 
	Thread *tf; 
	face_t f;
	real wallshear[ND_ND];
	tf = Lookup_Thread(d, face_ID);

	begin_f_loop(f,f_thread)
		{
			NV_V(wallshear,=,C_STORAGE_R_NV(f,tf,SV_WALL_SHEAR));
		} 
	end_f_loop(f,f_thread) 
	return wallshear[0]; // in x-direction
} 
*/