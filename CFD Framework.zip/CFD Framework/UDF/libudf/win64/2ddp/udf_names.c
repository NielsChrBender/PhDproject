/* This file generated automatically. */ 
/* Do not modify. */ 
#include "udf.h" 
#include "prop.h" 
#include "dpm.h" 
extern DEFINE_PROFILE(VelocityInlet_UDF,thread,i); 
extern DEFINE_PROFILE(PressureProfile,thread,i); 
extern DEFINE_PROFILE(PressureProfile0,thread,i); 
extern DEFINE_PROFILE(PressureProfile05,thread,i); 
extern DEFINE_PROFILE(PressureProfile1,thread,i); 
extern DEFINE_PROFILE(PressureProfile2,thread,i); 
extern DEFINE_PROFILE(PressureProfile3,thread,i); 
extern DEFINE_PROFILE(PressureProfile4,thread,i); 
extern DEFINE_PROFILE(PressureProfile5,thread,i); 
extern DEFINE_CG_MOTION(PlungerMovement,dt,vel,omega,time,dtime);
extern DEFINE_DYNAMIC_ZONE_PROPERTY(LayeringHeightUDF, dt, height);
extern DEFINE_PROPERTY(cell_viscosity,c,t);
extern DEFINE_PROPERTY(superfluid_density,c,t);
extern DEFINE_PROPERTY(sound_speed,c,t);
extern DEFINE_EXECUTE_ON_LOADING(initialize_parameters_func,libudf);
extern DEFINE_ON_DEMAND(end_of_step_print);
extern DEFINE_EXECUTE_AT_END(execute_at_end_udf);
extern DEFINE_ON_DEMAND(Process_initial_problem);
__declspec(dllexport) UDF_Data udf_data[] = { 
{"VelocityInlet_UDF", (void (*)(void))VelocityInlet_UDF, UDF_TYPE_PROFILE}, 
{"PressureProfile", (void (*)(void))PressureProfile, UDF_TYPE_PROFILE}, 
{"PressureProfile0", (void (*)(void))PressureProfile0, UDF_TYPE_PROFILE}, 
{"PressureProfile05", (void (*)(void))PressureProfile05, UDF_TYPE_PROFILE}, 
{"PressureProfile1", (void (*)(void))PressureProfile1, UDF_TYPE_PROFILE}, 
{"PressureProfile2", (void (*)(void))PressureProfile2, UDF_TYPE_PROFILE}, 
{"PressureProfile3", (void (*)(void))PressureProfile3, UDF_TYPE_PROFILE}, 
{"PressureProfile4", (void (*)(void))PressureProfile4, UDF_TYPE_PROFILE}, 
{"PressureProfile5", (void (*)(void))PressureProfile5, UDF_TYPE_PROFILE}, 
{"PlungerMovement", (void (*)(void))PlungerMovement, UDF_TYPE_CG_MOTION},
{"LayeringHeightUDF", (void (*)(void))LayeringHeightUDF, UDF_TYPE_DYNAMIC_ZONE_PROPERTY},
{"cell_viscosity", (void (*)(void))cell_viscosity, UDF_TYPE_PROPERTY},
{"superfluid_density", (void (*)(void))superfluid_density, UDF_TYPE_PROPERTY},
{"sound_speed", (void (*)(void))sound_speed, UDF_TYPE_PROPERTY},
{"initialize_parameters_func", (void (*)(void))initialize_parameters_func, UDF_TYPE_EXECUTE_ON_LOADING},
{"end_of_step_print", (void (*)(void))end_of_step_print, UDF_TYPE_ON_DEMAND},
{"execute_at_end_udf", (void (*)(void))execute_at_end_udf, UDF_TYPE_EXECUTE_AT_END},
{"Process_initial_problem", (void (*)(void))Process_initial_problem, UDF_TYPE_ON_DEMAND},
}; 
__declspec(dllexport) int n_udf_data = sizeof(udf_data)/sizeof(UDF_Data); 
#include "version.h" 
__declspec(dllexport) void UDF_Inquire_Release(int *major, int *minor, int *revision) 
{ 
*major = RampantReleaseMajor; 
*minor = RampantReleaseMinor; 
*revision = RampantReleaseRevision; 
} 
