%% CFD main, pick your weapon and fight!
fprintf('------------------- Main CFD initialized -------------------- \n');
% PICK THE SIMULATIONS
CFD_tutorial = 0;
trans_25mm_CFD_pres = 0;
trans_3D_CFD = 0;
trans_2D_para = 0;      % Transient analysis of the "actual" valve
static_2D = 0;          % Static analysis of the "actual" valve
dynamic_2D = 0;         % Simulate the "actual" valve dynamically
dynamic_2D_sensi = 0;   % Sensitivity simulations - dynamic for impact, displaced fluid and work
static_2D_sensi = 0;    % Sensitivity simulations - static for flow and force
dynamic_2D_sensi_cush =1;% Sensitivity simulations
dynamic_2D_reverse = 0; % Simulate from closed to open
dynamic_2D_cushion = 0; % Simulate the cushion design
%%% ------------ ALL THE SIMULATIONS ------------- %%%
if CFD_tutorial
    file = sprintf('%s%s',directory,strcat('CFD\CFDtutorial_DBR\Variations\Test_1\File_output\Analysis_data.out'));
    run(sprintf('%s%s',directory,strcat('CFD\examineAnalysis.m')))
    dos(sprintf('%s%s',directory,strcat('CFD\CFDtutorial_DBR\run_model.bat')));
end
if trans_25mm_CFD_pres % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_NCB25_big_motor';
    counter = 0;
    pres = [349.4e5 350e5];
    temp = 333.15;
    convergence = [5e-4 2e-4 1e-4];
    ke = [0 1];
    energy = [1];
    comp = 0;
    change_mesh = (1:1:1);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    mesh_path = [sprintf('"C:/MAIN/CFD/CFD_NCB25_big/stroke25_damping_inflation%s.msh"',strcat(num2str(change_mesh)))]; %stroke25_big_final_fine_inflation
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(mesh_path(:,1))
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    %write data to file
                    test = sprintf('"prestest_%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(M),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(j),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''comp ',num2str(comp),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(j)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_model.bat']);
                    %pause(25);
                    %wait for listener folder to be deleted by fluent
                    while(exist([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(j)])==7)
                        pause(0.25);
                    end
                end
            end
        end
    end
end
if trans_3D_CFD
    model_dir = 'C:\Fluent\SteadyFlow_test1';
    Positions = (-10:1:10);%(-10:1:10); %Number of mesh updates, 0.1mm per update
    %max flow rate 125 l/min prototype valve
    Flowrates = (-125:25:-25);%(25:25:125); %(l/min)
    
    Nsim = length(Positions)*length(Flowrates);
    counter=0;
    for k=1:length(Positions)
        for g=1:length(Flowrates)
            counter = counter + 1;
            %calc parameters
            N = abs(Positions(k));
            direction = sign(Positions(k));
            velocity = (Flowrates(g)/60000)/5.496277600000000e-04; %(25/60000)/274.89e-6=1.515757818278827
            %check for existence of old result files, skip if present
            resultFile = [model_dir,'\ResultFiles\plungerForces_N_',num2str(N),'_Dir_',num2str(direction),'_Vel_',num2str(velocity,'%.7f'),'.frp']; % plungerForces_N_10_Dir_1_Vel_1.5157578.frp
            if exist(resultFile)
                fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),': Position: ',num2str(Positions(k)),' Flow: ',num2str(Flowrates(g)),', Result files already exist! - Skipping. \n'])
                %break;
            else
                if exist([model_dir,'\tempParameters.scm'])==2
                    delete([model_dir,'\tempParameters.scm']);
                end
                %write data to file
                fid = fopen([model_dir,'\tempParameters.scm'],'w');
                fprintf(fid, ['(rp-var-define ''VelocityInletValue ',num2str(velocity,'%.7f'),' ''real #f) \r\n']);
                fprintf(fid, ['(rp-var-define ''NumberOfMeshUpdates ',num2str(N),' ''integer #f) \r\n']);
                fprintf(fid, ['(rp-var-define ''meshupdatedirection ',num2str(direction),' ''real #f) \r\n']);
                fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),' ''integer #f) \r\n']);
                fclose(fid);
                %create listener folder
                mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g)])
                %run model
                fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),': Position: ',num2str(Positions(k)),' Flow: ',num2str(Flowrates(g)),', Running ... '])
                [s,w]=dos([model_dir,'\run_model.bat']);
                %wait for listener folder to be deleted by fluent
                while(exist([model_dir,'\Listener_ID_',num2str(k),num2str(g)])==7)
                    pause(0.25);
                end
                fprintf('DONE! \n')
            end
        end
    end
end
if trans_2D_para % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_transient';
    % Coarse mesh is 1 fine is higher number : extra fine 147308 elements
    counter = 0;
    pres = linspace(4.42e5,5.68e5,2);
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    change_mesh = (4:1:4);
    change_mesh = [25 20 15 10 5 1 115 111]; % 2.5, 2, 1, mm The last are 0.5 mm, 0.15 mm, 0.05 mm, 0.01 mm
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/CFD_static/static_4_%s.msh"',strcat(num2str(change_mesh(m))))];
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    %write data to file
                    test = sprintf('"Posprestest_%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(M),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(j),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(j),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_transientmodel.bat']);
                    %pause(25);
                    %wait for listener folder to be deleted by fluent
                    while(exist([model_dir,'\Listener_ID_',num2str(k),num2str(j),num2str(m)])==7)
                        pause(0.25);
                    end
                end
            end
        end
    end
end
if static_2D % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_static';
    % Coarse mesh is 1 fine is higher number :fine 24324 elements extra fine 147308 elements
    counter = 0;
    pres = linspace(4.32e5,5.68e5,10);
    %pres = [4.82e5 5.48e5];
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    change_mesh = [25 20 15 10 5 1]; % 2.5, 2, 1, mm The last two are 0.5 mm and 0.15 mm
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/CFD_static/static_4_%s.msh"',strcat(num2str(change_mesh(m))))];
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    %write data to file
                    test = sprintf('"Areaprestest_%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(M),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(j),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(j),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_staticmodel.bat']);
                    %pause(25);
                    %wait for listener folder to be deleted by fluent
                    while(exist([model_dir,'\Listener_ID_',num2str(k),num2str(j),num2str(m)])==7)
                        pause(0.25);
                    end
                end
            end
        end
    end
end

if dynamic_2D % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_NCB25_big_motor';
    counter = 0;
    pres = [0];
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    comp = 0;
    change_mesh = (1:1:1);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/CFD_NCB25_big/dynamic_%s.msh"',strcat(num2str(change_mesh(m))))]; %stroke25_big_final_fine_inflation
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    test = sprintf('"Constmov0001_%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(2),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''comp ',num2str(comp),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_model.bat']);
                    if Nsim > 1
                        pause(25);
                    else
                    end
                end
            end
        end
    end
end

if dynamic_2D_sensi % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_NCB25_big_motor';
    counter = 0;
    pres = [0e5];
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    comp = 0;
    change_mesh = (5:1:6);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/Topology1DesignSensi/dynamic_2_L0%s.msh"',strcat(num2str(M)))]; %stroke25_big_final_fine_inflation
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    test = sprintf('"SensiL0%s"',strcat(num2str(M)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(2),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''comp ',num2str(comp),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_model.bat']);
                    if Nsim > 1
                        pause(25);
                    else
                    end
                end
            end
        end
    end
end

if static_2D_sensi % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_static';
    counter = 0;
    pres = linspace(4.32e5,5.68e5,10);
    temp = 333.15;
    convergence = [1e-4];
    ke = [2];
    energy = [0];
    comp = 0;
    change_mesh = (16:1:20);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/Topology2DesignSensi/R-ls-L1-15-25-%s.msh"',strcat(num2str(M)))]; %Topology1DesignSensi/dynamic_2_L0%s.msh
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    test = sprintf('"StaticSensiC%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(4),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''comp ',num2str(comp),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_staticmodel_sensi.bat']);
                    if Nsim > 1
                        pause(40);
                    else
                    end
                end
            end
        end
    end
end

if dynamic_2D_sensi_cush % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_NCB25_big_motor';
    counter = 0;
    pres = [350e5];
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    comp = 0;
    change_mesh = (16:4:20);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/Topology2DesignSensi/R-ls-L1-15-25-%s.msh"',strcat(num2str(M)))]; %stroke25_big_final_fine_inflation
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    test = sprintf('"Sensi350C%s"',strcat(num2str(M)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(4),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''comp ',num2str(comp),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_model.bat']);
                    if Nsim > 1
                        pause(25);
                    else
                    end
                end
            end
        end
    end
end

if dynamic_2D_cushion % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_NCB25_big_motor';
    counter = 0;
    pres = [0]*1e5;
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    comp = [1];
    change_mesh = (4:1:4);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/CFD_NCB25_big/stroke25_damping_inflation%s.msh"',strcat(num2str(change_mesh(m))))]; %stroke25_big_final_fine_inflation
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    test = sprintf('"Cushion_%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(M),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''comp ',num2str(comp),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_model.bat']);
                    pause(25);
                end
            end
        end
    end
end

if dynamic_2D_reverse % simulation that terminates after X*Y iterations of fluent - possible to have different designs
    model_dir = 'C:\MAIN\CFD\CFD_NCB25_big_motor_reverse';
    counter = 0;
    pres = [349.8 349.5 349]*1e5;
    temp = 333.15;
    convergence = [1e-4];
    ke = [0];
    energy = [0];
    change_mesh = (2:1:2);
    Nsim = length(pres)*length(convergence)*length(ke)*length(change_mesh);
    for k=1:length(pres)
        for g=1:length(convergence)
            for j=1:length(ke)
                for m=1:length(change_mesh)
                    counter=counter+1;
                    model = ke(j);
                    P = pres(k);
                    C = convergence(g);
                    M = change_mesh(m);
                    mesh_path = [sprintf('"C:/MAIN/CFD/CFD_NCB25_big/stroke25_reverse.msh"',strcat(num2str(change_mesh(m))))]; %stroke25_big_final_fine_inflation
                    mesh = mesh_path(1,:);
                    if exist([model_dir,'\tempParameters.scm'])==2
                        delete([model_dir,'\tempParameters.scm']);
                    end
                    test = sprintf('"Constmov_%s"',strcat(num2str(counter)));
                    fid = fopen([model_dir,'\tempParameters.scm'],'w');
                    fprintf(fid, ['(rp-var-define ''PressureInletValue ',num2str(P),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''TempBoundary ',num2str(temp),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''convcrit ',num2str(C),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''ke ',num2str(model),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''variation_dir ',test,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_dir ',mesh,' ''string #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''mesh_nr ',num2str(2),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''listenerID ',num2str(k),num2str(g),num2str(m),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''test_nr ',num2str(counter),' ''integer #f) \r\n']);
                    fprintf(fid, ['(rp-var-define ''energy ',num2str(energy),' ''integer #f) \r\n']);
                    fclose(fid);
                    %create listener folder
                    mkdir([model_dir,'\Listener_ID_',num2str(k),num2str(g),num2str(m)])
                    %run model
                    fprintf(['Simulation ',num2str(counter),'/',num2str(Nsim),', Running ... '])
                    [s,w]=dos([model_dir,'\run_model.bat']);
                    pause(25);
                end
            end
        end
    end
end

fprintf('----------------------- Main CFD end ------------------------ \n');
