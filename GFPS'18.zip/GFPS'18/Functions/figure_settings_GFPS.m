function [] = figure_settings_GFPS(name,fontsize,xlabels,ylabels,hh)
% 2D plot settings
grid on;
box on;
set(hh,'location','best','Interpreter','latex');
set(gca,'GridLineStyle', '-.');
set(gca,'FontSize', fontsize);
set(gca,'FontName','Times New Roman');
set(gcf,'PaperPositionMode','auto','paperorientation','landscape');
set(gcf,'PaperPosition',[0 0 30 15]);
set(gcf,'PaperSize',[30 15]);
set(gcf,'Color','white');
xlabel(xlabels);
ylabel(ylabels);
fname = 'C:\MAIN\Figures\Figures_GFPS18';
saveas(gca,fullfile(fname, name), 'pdf');
close
end