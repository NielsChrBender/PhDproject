function [] = figure_settings_GFPS_cont(name,fontsize,xlabels,ylabels,zlabels)
% 2D plot settings
colormap(winter); 
colorbar;
c = colorbar; 
c.Label.String = zlabels;            
grid on;
box on;
set(gca,'GridLineStyle', '-.');
set(gca,'FontSize', fontsize);
set(gca,'FontName','Times New Roman');
set(gcf,'PaperPosition',[0 0 19 16]);
set(gcf,'PaperSize',[19 16]);
set(gcf,'Color','white');
xlabel(xlabels);
ylabel(ylabels);
fname = 'C:\MAIN\Figures\Figures_GFPS18';
saveas(gca,fullfile(fname, name), 'pdf');
close
end