%% DYNAMIC MODEL OF THE DDP WITH HPV & LPV 
nu              = 46e-6;            % Fluid viscosity
rho             = 870;              % Fluid density [kg/m^3]
mu              = nu*rho;           % Dynamic fluid viscosity [kg/(m s)]
l_stroke        = 2.5e-3;           % Valve stroke length
ddotx_0         = 0;                % Initial acceleration
theta_ini       = 0;%pi-thetaOffset;   % CHECK THIS!!
RPM             = 400;              % Rated rotations per minute
RPM_M           = 800;              % Rated rotations per minute
dottheta_ini    = RPM/60*2*pi;      % Angular velocity
dottheta_ini_M  = RPM_M/60*2*pi;      % Angular velocity
factor          = 5e-3;             % reduction of the INSANE sampletime
sample          = 1/(0.00117272740100000-0.00117271940100000)*factor;
fixed_time_step = 1/sample;         % Time step
p_H             = 350e5;            % High pressure mfd
p_L             = 5e4;              % Low pressure mfd
p_ini1          = p_H;              % Initial pressure
p_ini2          = p_L;              % Initial pressure
p_ini3          = p_L;              % Initial pressure
p_ini4          = p_H;              % Initial pressure
p_ini5          = p_H;              % Initial pressure
p_ini1_M        = p_L;              % Initial pressure
p_ini2_M        = p_H;              % Initial pressure
p_ini3_M        = p_H;              % Initial pressure
p_ini4_M        = p_L;              % Initial pressure
p_ini5_M        = p_L;              % Initial pressure
tau_valve       = 1e-3; 

I_r             = 0.2:0.05:1;
a               = 2;
Q_leakH         = 0*0.0005/(60000*(p_H-p_L)); 
Q_leakL         = 0*0.0005/(60000*(p_H-p_L));
%f_leakH         = I_r*Q_leakH*t^a;
%f_leakL         = I_r*Q_leakL*t^a;

%% Fluid movement coefficients
d_mean          = (17.6e-3^2+12.4e-3^2)/2;
A_c_valves      = pi*(d_mean);    % [m^2] Effective area for the cylinder pressure on the valves

%% Lobe Pump param
A_c_p_P         = pi*(45e-3)^2;
r_P             = 75e-3/2;
lobes           = 16; 
p_HP            = 360e5;            % High pressure mfd
p_LP            = 10e4;              % Low pressure mfd

%% Cylinder constants
l_strokecyl     = 49.12e-3;         % previous dar�ta(4/pi*50e-6)^(1/3);
A_c_p           = pi*(18e-3)^2;     % Piston Area 
Cylinder_volume = l_strokecyl*A_c_p;
V_0             = 62e-6;            % V_dead+A_c_p*l_stroke;     % Cylinder volume at bottom position               
r_e             = l_strokecyl/2;    % Exentric radius
del             = 0*pi/180;
sw_int          = 3*pi/180;
theta_HP        = pi+del;
theta_LP        = -del;

theta_HP1       = 0-del;
theta_LP1       = pi+theta_HP1+del;
theta_HP2       = 2*pi/5-del;
theta_LP2       = pi+theta_HP2+del;
theta_HP3       = 2*2*pi/5-del;
theta_LP3       = pi+theta_HP3+del;
theta_HP4       = 3*2*pi/5-del;
theta_LP4       = pi+theta_HP4+del-2*pi;
theta_HP5       = 4*2*pi/5-del;
theta_LP5       = pi+theta_HP5+del-2*pi;

theta_HP1_M     = mod(pi+del,2*pi);
theta_LP1_M     = mod(0,2*pi);
theta_HP2_M     = mod(theta_HP1_M+2*pi/5,2*pi);
theta_LP2_M     = mod(theta_LP1_M+2*pi/5,2*pi);
theta_HP3_M     = mod(theta_HP2_M+2*pi/5,2*pi);
theta_LP3_M     = mod(theta_LP2_M+2*pi/5,2*pi);
theta_HP4_M     = mod(theta_HP3_M+2*pi/5,2*pi);
theta_LP4_M     = mod(theta_LP3_M+2*pi/5,2*pi);
theta_HP5_M     = mod(theta_HP4_M+2*pi/5,2*pi);
theta_LP5_M     = mod(theta_LP4_M+2*pi/5,2*pi);

%% RUN THE MODEL STUFF
Tsim_P          = 1*1/(RPM/60);%thetaOffset/dottheta_ini;%0.005;
Tsim_M          = 1*1/(RPM_M/60);%thetaOffset/dottheta_ini;%0.005;
Decimation      = 5; 
Sample_time     = -1;
