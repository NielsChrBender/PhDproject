fprintf('------------------- Main motor dynamics with leakage V.4 initialized -------------------- \n');
%% -------------- Simulation configuration -------------------------
stiction_on                 = 0;    % Turn on stiction
squeeze_on                  = 1;    % Squeeze on
Compare_CFD                 = 0;    % Compare results with CFD
Enable_LP_and_HP_CV_coupling= 1;    % Test with volume change from valves
LPM                         = 1;    % Lumped fluid parameters used in main model (always used in model 2)
fontsize                    = 16;
%% -------------- External file execution -------------------------
%path = sprintf('%s%s',directory,strcat('LeakageStudy\Leak_parameters.m'));       % Insert folder direction
path                = sprintf('%s%s',directory,strcat('constants.m'));       % Insert folder direction
run(path); %Run file with constants
ratio               = (const.r_e*const.RPM_M)/(const.r_P*const.RPM*const.lobes);
leakage_factorsHP   = 0:1:3;
leakage_factorsLP   = 0:1:3;
const.max_flow      = 125.6589;
const.per_leak_flow = 1e-2;
E_out_id            = const.Cylinder_volume*(-const.E_0*(exp(-(const.p_H-const.p_L)/const.E_0)+exp((const.p_H-const.p_L)/const.E_0)-2)*const.V_0/const.Cylinder_volume-const.E_0*(exp(-(const.p_H-const.p_L)/const.E_0)-1));
for i = 1:length(leakage_factorsHP)
    for k = 1:length(leakage_factorsLP)
        % PUMP SIMULATION - SOME CONSTANTS ARE UPDATED WHICH MAKES IT
        % POSSIBLE TO USE THE SAME SIMULINK MODEL FOR BOTH PUMP AND MOTOR
        const.idle          = 0;
        const.Q_leakH       = leakage_factorsHP(i)*const.max_flow*const.per_leak_flow*0.34/(60000*(const.p_H-const.p_L));
        const.Q_leakL       = leakage_factorsLP(k)*const.max_flow*const.per_leak_flow*0.34/(60000*(const.p_H-const.p_L));
        run('pump_settings')
        E_out_id_P          = const.Cylinder_volume_P*(-const.E_0*(exp(-(const.p_H-const.p_L)/const.E_0)+exp((const.p_H-const.p_L)/const.E_0)-2)*const.V_0/const.Cylinder_volume_P-const.E_0*(exp(-(const.p_H-const.p_L)/const.E_0)-1));
        tStart              = tic;         %Start time
        path = sprintf('%s%s',directory,strcat('Dynamic\Singlechamber'));
        sim(path);
        tElapsed            = toc(tStart); %Stop time
        E_in_P_cycle(i,k)   = -E_out_M(end);
        E_out_P_cycle(i,k)  = E_in_M1(end);
        E_F_P_cycle(i,k)    = E_F(end);
        W_H_P(i,k)          = trapz(z_H,F_workH)-trapz(z_H,zddot_H*const.m);
        W_L_P(i,k)          = trapz(z_L,F_workL)-trapz(z_L,zddot_L*const.m);
        W_H_Pflow(i,k)      = trapz(z_H,F_flowTermH(1:round(length(F_flowTermH)/length(z_H)):end));
        W_L_Pflow(i,k)      = trapz(z_L,F_flowTermL(1:round(length(F_flowTermH)/length(z_H)):end));
        E_loss_P_cycle(i,k) = -W_H_P(i,k)-W_L_P(i,k)+E_F(end)-W_H_Pflow(i,k)-W_L_Pflow(i,k); %-W_H_Pflow(i,k)-W_L_Pflow(i,k)
        eta_cycle_P(i,k)    = 1-(E_loss_P_cycle(i,k))/(E_in_P_cycle(i,k));
        fprintf([datestr(now),' DDP simulation time: ',num2str(tElapsed,'%10.1f'),'[s]', 'simulation number:',num2str(i),'.',num2str(k), 'eta =',num2str(eta_cycle_P(i,k)), '\n']);
        run(sprintf('%s%s',directory,strcat('Machine_eval_plot.m')));
        % MOTOR SIMULATION
        run('motor_settings')
        tStart              = tic;         %Start time
        path = sprintf('%s%s',directory,strcat('Dynamic\Singlechamber'));
        sim(path);
        tElapsed            = toc(tStart); %Stop time
        E_in_M_cycle(i,k)   = E_in_M(end);
        E_out_M_cycle(i,k)  = E_out_M(end);
        E_F_M_cycle(i,k)    = E_F(end);
        W_H(i,k)            = trapz(z_H,F_workH)-trapz(z_H,zddot_H*const.m);
        W_L(i,k)            = trapz(z_L,F_workL)-trapz(z_L,zddot_L*const.m);
        W_Hflow(i,k)        = trapz(z_H,F_flowTermH(1:round(length(F_flowTermH)/length(z_H)):end));
        W_Lflow(i,k)        = trapz(z_L,F_flowTermL(1:round(length(F_flowTermH)/length(z_H)):end));
        E_loss_M_cycle(i,k) = -W_H(i,k)-W_L(i,k)+E_F(end)-W_Hflow(i,k)-W_Lflow(i,k); %-W_Hflow(i,k)-W_Lflow(i,k)
        eta_cycle_M(i,k)    = 1-(E_loss_M_cycle(i,k))/(E_in_M_cycle(i,k));
        fprintf([datestr(now),' DDM simulation time: ',num2str(tElapsed,'%10.1f'),'[s]', 'simulation number:',num2str(i),'.',num2str(k), 'eta =',num2str(eta_cycle_M(i,k)), '\n']);
        run(sprintf('%s%s',directory,strcat('Machine_eval_plot.m')));      
    end
    %% IDLE MOTOR SIMULATION
    const.idle      = 1;
    run('motor_settings')
    tStart = tic;         %Start time
    path = sprintf('%s%s',directory,strcat('Dynamic\Singlechamber'));
    sim(path);
    tElapsed = toc(tStart); %Stop time
    E_out_cycle_I(i) = E_in_M1(end);
    E_loss_cycle_I(i) = E_F(end);%E_in_M(end);
    fprintf([datestr(now),' DDM idle simulation time: ',num2str(tElapsed,'%10.1f'),'[s]', 'simulation number:',num2str(i),'.',num2str(k), ' =',num2str(E_out_cycle_I(i)),',',num2str(E_loss_cycle_I(i)), '\n']);
    run(sprintf('%s%s',directory,strcat('Machine_eval_plot.m')));       % Insert folder direction
    % IDLE PUMP SIMULATION
    run('pump_settings')
    tStart = tic;         %Start time
    path = sprintf('%s%s',directory,strcat('Dynamic\Singlechamber'));
    sim(path);
    tElapsed = toc(tStart); %Stop time
    E_out_cycle_PI(i) = E_in_M1(end);
    E_loss_cycle_PI(i) = E_F(end);
    fprintf([datestr(now),' DDP idle simulation time: ',num2str(tElapsed,'%10.1f'),'[s]', 'simulation number:',num2str(i),'.',num2str(k), ' =',num2str(E_out_cycle_PI(i)),',',num2str(E_loss_cycle_PI(i)), '\n']);
    run(sprintf('%s%s',directory,strcat('Machine_eval_plot.m')));       % Insert folder direction
end
save('eta_P.mat','E_in_P_cycle','E_out_P_cycle','E_loss_P_cycle','eta_cycle_P')
save('eta_M.mat','E_in_M_cycle','E_out_M_cycle','E_loss_M_cycle','eta_cycle_M')
save('eta_I.mat','E_out_cycle_I','E_loss_cycle_I','E_out_cycle_PI','E_loss_cycle_PI')

%% Theoretical losses
t_stat = tic;
f_C_D = @(deltap,z) interp2(Openings,pres_seq,C_d,z,deltap,'linear',0); 
const.A_c_p  = pi*(18e-3)^2;
const.A_c_p_P  = ratio*pi*(18e-3)^2;
const.dottheta_ini_M = const.RPM_M/60*2*pi;
const.dottheta_ini = const.RPM/60*2*pi;
t_M = 1/(const.RPM_M/60);
t_M_H = (const.theta_HP_M-pi)/const.dottheta_ini_M;
t_M_L = (const.theta_LP_M-0)/const.dottheta_ini_M;
t_P = 1/(const.RPM/60*const.lobes);
t_P_H = (2*pi-const.theta_HP_P)/(const.dottheta_ini*const.lobes);
t_P_L = (pi-const.theta_LP_P)/(const.dottheta_ini*const.lobes);
D_M_H = const.A_c_p*(abs(cos(const.theta_HP_M))+1)*const.r_e;
D_M_L = const.A_c_p*(abs(cos(const.theta_LP_M))+1)*const.r_e;
D_P_H = const.A_c_p_P*(abs(cos(const.theta_HP_P))+1)*const.r_P;
D_P_L = const.A_c_p_P*(abs(cos(const.theta_LP_P))+1)*const.r_P;
Q_leak = 0;
Q_mean_M_H = D_M_H/t_M_H;
Q_mean_M_L = D_M_L/t_M_L;
Q_mean_P_H = D_P_H/t_P_H;
Q_mean_P_L = D_P_L/t_P_L;
delta_p_mean_M_H = (Q_mean_M_H/(f_C_D(0.25e5,2.5e-3)*2*pi*2.5e-3*(const.r_in1+const.r_out2)*sqrt(2/const.rho)))^2;
delta_p_mean_M_L = (Q_mean_M_L/(f_C_D(0.25e5,2.5e-3)*2*pi*2.5e-3*(const.r_in1+const.r_out2)*sqrt(2/const.rho)))^2;
delta_p_mean_P_H = (Q_mean_P_H/(f_C_D(0.25e5,2.5e-3)*2*pi*2.5e-3*(const.r_in1+const.r_out2)*sqrt(2/const.rho)))^2;
delta_p_mean_P_L = (Q_mean_P_L/(f_C_D(0.25e5,2.5e-3)*2*pi*2.5e-3*(const.r_in1+const.r_out2)*sqrt(2/const.rho)))^2;
E_loss_M = @(Q_lH,Q_lL) (t_M/2*Q_lH*(const.p_H-const.p_L)+t_M/2*Q_lL*(const.p_H-const.p_L)+Q_mean_M_H*delta_p_mean_M_H*t_M_H+Q_mean_M_L*delta_p_mean_M_L*t_M_L);
E_loss_P = @(Q_lH,Q_lL) (t_P/2*Q_lH*(const.p_HP-const.p_LP)+t_P/2*Q_lL*(const.p_HP-const.p_LP)+Q_mean_P_H*delta_p_mean_P_H*t_P_H+Q_mean_P_L*delta_p_mean_P_L*t_P_H);
E_loss_MI = @(Q_lH) ((t_M)*Q_lH*(const.p_H-const.p_L)+Q_mean_M_L*delta_p_mean_M_L*t_M);
E_loss_PI = @(Q_lH) ((t_P)*Q_lH*(const.p_HP-const.p_LP)+Q_mean_P_L*delta_p_mean_P_L*t_P);
T_switchH1 = (29.8-28.14)*1e-3; T_switchH2 = (35.04-33.3)*1e-3; T_switchL1 = 2e-3; T_switchL2 = 2e-3;
Amp = const.l_stroke;
omega = 1/(T_switchH1+T_switchH2);
E_force = 2*(8/3*7*Amp*omega+(4+const.B_bcoef)*pi+2*((const.m+const.K_a)*omega))*omega*Amp^2;
A = 1.1*2*pi*Amp*(const.r_in1+const.r_out2);
E_flow = @(Q_mean,delta_p) Q_mean^2*const.rho*Amp/A+delta_p*(const.fitA_P1*Amp^(const.fitA_P2+1)/(const.fitA_P2+1)+const.fitA_P3*Amp);
E_flow_H = -E_flow(Q_mean_M_H,delta_p_mean_M_H)-E_flow(0,0.4e5); 
E_flow_L = -E_flow(Q_mean_M_L,delta_p_mean_M_L)-E_flow(0,0.4e5); 
E_flow_H_P = -E_flow(-Q_mean_P_H,-delta_p_mean_P_H)-E_flow(0,0.4e5); 
E_flow_L_P = -E_flow(-Q_mean_P_L,-delta_p_mean_P_L)-E_flow(0,0.4e5);
E_W_M = E_flow_H+E_flow_L+E_force;
E_W_P = E_flow_H_P+E_flow_L_P+E_force;
% Heat losses during compression
% mass_air = (const.V_0+const.A_c_p*const.r_e*0.2)*const.rho_air*0.05;
% temp_change = exp((const.R_air*log(const.p_H/const.p_L))/const.c_p)*const.Temp;
% E_comp = (temp_change-const.Temp)*const.c_p*mass_air;
func_eta_M = @(gamma,Q_lH,Q_lL) 1-((E_W_M+E_loss_M(Q_lH,Q_lL))*gamma+(1-gamma)*E_loss_MI(Q_lH))/(E_out_id*gamma); %E_in(D_M)
func_eta_P = @(gamma,Q_lH,Q_lL) 1-((E_W_P+E_loss_P(Q_lH,Q_lL))*gamma+(1-gamma)*E_loss_PI(Q_lH))/(E_out_id_P*gamma); %E_in(D_P)
eta_M_stat = func_eta_M(1,0,0);
eta_P_stat = func_eta_P(1,0,0);
eta_M_stat_1 = func_eta_M(1,const.max_flow*const.per_leak_flow/60000,const.max_flow*const.per_leak_flow/60000);
eta_P_stat_1 = func_eta_P(1,const.max_flow*const.per_leak_flow/60000,const.max_flow*const.per_leak_flow/60000);
t_stat_end = toc(t_stat);

%% PLOTS AND COMPUTATIONS FOR MAIN LAKAGE LOSSES
%load('C:\MAIN\LeakageStudy\eta_P.mat'); %Lookup_tables
%load('C:\MAIN\LeakageStudy\eta_M.mat');
%load('C:\MAIN\LeakageStudy\eta_I.mat');
Q_rated_M = const.A_c_p*const.r_e*const.RPM_M/60*2*pi;
Q_rated_P = const.lobes*const.A_c_p_P*const.r_P*const.RPM/60*2*pi;
N_cunt = 10;
[X,Y] = meshgrid(100*const.max_flow*const.per_leak_flow*leakage_factorsHP*0.34/(Q_rated_P*60000),100*const.max_flow*const.per_leak_flow*leakage_factorsLP*0.34/(Q_rated_P*60000));
Z = eta_cycle_P/eta_cycle_P(1,1);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on'); 
figure_settings_GFPS_cont('etaP',fontsize,'HPV leakage percentage [%]','LPV leakage percentage [%]','\eta_P/ \eta_{P0}') % name, fontsize, xlabel, ylabel, legends

[X,Y] = meshgrid(100*const.max_flow*const.per_leak_flow*leakage_factorsHP*0.34/(Q_rated_M*60000),100*const.max_flow*const.per_leak_flow*leakage_factorsLP*0.34/(Q_rated_M*60000));
Z = eta_cycle_M/eta_cycle_M(1,1);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on');
figure_settings_GFPS_cont('etaM',fontsize,'HPV leakage percentage [%]','LPV leakage percentage [%]','\eta_M/ \eta_{M0}') % name, fontsize, xlabel, ylabel, legends

[X,Y] = meshgrid(100*const.max_flow*const.per_leak_flow*leakage_factorsHP*0.34/(Q_rated_M*60000),100*const.max_flow*const.per_leak_flow*leakage_factorsLP*0.34/(Q_rated_M*60000));
Z = func_eta_M(1,const.max_flow*X/60000*const.per_leak_flow,const.max_flow*Y/(60000)*const.per_leak_flow)./func_eta_M(1,0,0);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on');
figure_settings_GFPS_cont('etaM_theo',fontsize,'HPV leakage percentage [%]','LPV leakage percentage [%]','\eta_{M,static}/ \eta_{M0,static}') % name, fontsize, xlabel, ylabel, legends

%% SYMMETRY CHECK OF LEAKAGE FROM HPV AND LPV
eta_sym_M = 0.5*(eta_cycle_M+transpose(eta_cycle_M));
eta_asym_M = 0.5*(eta_cycle_M-transpose(eta_cycle_M));
Psi_M = (norm(eta_sym_M,1)-norm(eta_asym_M,1))/(norm(eta_sym_M,1)+norm(eta_asym_M,1));
eta_sym_M_stat = 0.5*(Z+transpose(Z));
eta_asym_M_stat = 0.5*(Z-transpose(Z));
Psi_M_stat = (norm(eta_sym_M_stat,1)-norm(eta_asym_M_stat,1))/(norm(eta_sym_M_stat,1)+norm(eta_asym_M_stat,1));
eta_sym_P = 0.5*(eta_cycle_P+transpose(eta_cycle_P));
eta_asym_P = 0.5*(eta_cycle_P-transpose(eta_cycle_P));
Psi_P = (norm(eta_sym_P,1)-norm(eta_asym_P,1))/(norm(eta_sym_P,1)+norm(eta_asym_P,1));

%% IDLE EFFICIENCIES
Q_l = linspace(1,4,20);
Q_h = Q_l;
leak_frac = 1/3;
clear eta_P_I eta_M_I eta_P_theo eta_M_theo
gamma = linspace(0.2,1,20);
for i = 1:length(gamma)
    for k = 1:length(Q_l)
        E_loss_P_lin = interp2(E_loss_P_cycle,Q_h(k),Q_l(k),'linear');
        E_loss_M_lin = interp2(E_loss_M_cycle,Q_h(k),Q_l(k),'linear');
        E_loss_PI_lin = interp1(E_loss_cycle_PI,Q_h(k),'linear');
        E_loss_I_lin = interp1(E_loss_cycle_I,Q_h(k),'linear');
        E_in_P_lin = interp2(E_in_P_cycle,Q_h(k),Q_l(k),'linear');
        E_in_M_lin = interp2(E_in_M_cycle,Q_h(k),Q_l(k),'linear');
        eta_P_I(k,i) = 1-((E_loss_P_lin)*gamma(i)+(1-gamma(i))*E_loss_PI_lin)/(E_in_P_lin*gamma(i));
        eta_M_I(k,i) = 1-((E_loss_M_lin)*gamma(i)+(1-gamma(i))*E_loss_I_lin)/(E_in_M_lin*gamma(i));
        leak_M = (Q_l(k)-1)*leak_frac*(Q_rated_M)*const.per_leak_flow;
        leak_P = (Q_l(k)-1)*leak_frac*(Q_rated_P)*const.per_leak_flow;
        eta_M_theo(k,i) = func_eta_M(gamma(i),leak_M,leak_M);
        eta_P_theo(k,i) = func_eta_P(gamma(i),leak_P,leak_P);
    end
end

[X,Y] = meshgrid(gamma,100*const.max_flow*const.per_leak_flow*(Q_l-1)*0.34/(Q_rated_P*60000));
Z = eta_P_theo/eta_P_theo(1,1);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on');
figure_settings_GFPS_cont('etaPI_theo',fontsize,'\gamma [-]','Leakage percentage [%]','\eta_{P,\gamma,static}/ \eta_{P0,\gamma,static}') % name, fontsize, xlabel, ylabel, legends

Z = eta_P_I/eta_P_I(1,end);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on');
figure_settings_GFPS_cont('etaPI',fontsize,'\gamma [-]','Leakage percentage [%]','\eta_{P,\gamma}/ \eta_{P0,\gamma}') % name, fontsize, xlabel, ylabel, legends

[X,Y] = meshgrid(gamma,100*const.max_flow*const.per_leak_flow*(Q_l-1)*0.34/(Q_rated_M*60000));
Z = eta_M_I/eta_M_I(1,end);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on');
set(gca,'ZTick',0.9:1e-3:1,'ZTickLabel',0.9:1e-3:1)
figure_settings_GFPS_cont('etaMI',fontsize,'\gamma [-]','leakage percentage [%]','\eta_{M,\gamma}/ \eta_{M0,\gamma}') % name, fontsize, xlabel, ylabel, legends

Z = eta_M_theo/eta_M_theo(1,1);
figure
contourf(X,Y,Z,N_cunt,'ShowText','on');
figure_settings_GFPS_cont('etaMI_theo',fontsize,'\gamma [-]','leakage percentage [%]','\eta_{M,\gamma,static}/ \eta_{M0,\gamma,static}') % name, fontsize, xlabel, ylabel, legends

%% TIME-DEPENDENT EFFICIENCY WHEN LEAKAGE IS A FUNCTION OF CYCLES
clear gamma chi_aM eta_M_theo_time eta_P_theo_time eta_P_I_time eta_M_I_time
t_life = 25;
M_vload = const.RPM_M*60*24*365;
P_vload = const.lobes*const.RPM*60*24*365;
N_num = 1:1:(365*t_life);
alpha = 0.0038;
lambda = 1.73;
gamma = linspace(0.2,1,5);
for i = 1:length(gamma)
    for k = 1:length(N_num)
        N_num1 = gamma(i)*N_num(k)/(365)*M_vload;
        N_num2 = gamma(i)*N_num(k)/(365)*P_vload;
        chi_aM(i,k) = alpha*(N_num1/M_vload)^lambda;
        chi_aP = alpha*(N_num2/M_vload)^lambda;
        chi_dM(i,k) = 0.1*(1-exp(-25*N_num1/M_vload));
        chi_dP = 0.1*(1-exp(-25*N_num2/M_vload));
        Q_lM = 1+3*chi_aM(i,k);
        Q_lP = 1+3*chi_aP;
        Q_hM = 1+3*chi_aM(i,k);
        Q_hP = 1+3*chi_aP;
        E_loss_P_lin = interp2(E_loss_P_cycle,Q_hP,Q_lP,'linear');
        E_loss_M_lin = interp2(E_loss_M_cycle,Q_hM,Q_lM,'linear');
        E_loss_PI_lin = interp1(E_loss_cycle_PI,Q_hP,'linear');
        E_loss_I_lin = interp1(E_loss_cycle_I,Q_hM,'linear');
        E_in_P_lin = interp2(E_in_P_cycle,Q_hP,Q_lP,'linear');
        E_in_M_lin = interp2(E_in_M_cycle,Q_hM,Q_lM,'linear');
        eta_P_I_time(k,i) = 1-(E_loss_P_lin*gamma(i)+(1-gamma(i))*E_loss_PI_lin)/(E_in_P_lin*gamma(i));
        eta_M_I_time(k,i) = 1-(E_loss_M_lin*gamma(i)+(1-gamma(i))*E_loss_I_lin)/(E_in_M_lin*gamma(i));
        leak_LM = (Q_lM-1)*leak_frac*(Q_rated_M)*const.per_leak_flow;
        leak_HM = (Q_hM-1)*leak_frac*(Q_rated_M)*const.per_leak_flow;
        leak_HP = (Q_hP-1)*leak_frac*(Q_rated_P)*const.per_leak_flow;
        leak_LP = (Q_lP-1)*leak_frac*(Q_rated_P)*const.per_leak_flow;
        eta_M_theo_time(k,i) = func_eta_M(gamma(i),leak_HM,leak_LM);
        eta_P_theo_time(k,i) = func_eta_P(gamma(i),leak_HP,leak_LP);
    end
end

figure
plot(N_num/365,eta_P_I_time,'linewidth',2)
hh = legend('$\gamma = 0.2$','$\gamma = 0.4$','$\gamma = 0.6$','$\gamma = 0.8$','$\gamma = 1$'); %set(hh,'location','southwest','Interpreter','latex')
figure_settings_GFPS('etaPItime',fontsize,'Time [years]','Efficiency, \eta_{P,\gamma} [-]',hh) % name, fontsize, xlabel, ylabel, legends

figure
plot(N_num/365,eta_M_I_time,'linewidth',2)
hh = legend('$\gamma = 0.2$','$\gamma = 0.4$','$\gamma = 0.6$','$\gamma = 0.8$','$\gamma = 1$');
figure_settings_GFPS('etaMItime',fontsize,'Time [years]','Efficiency, \eta_{M,\gamma} [-]',hh) % name, fontsize, xlabel, ylabel, legends

Y = [0.95 0.95];
X = [0 N_num(end)/365];
figure
H = area(X,Y,'LineStyle','-'); H(1).FaceColor = [0 0.2 0.2]; H(1).FaceAlpha = 0.3;
hold all, plot(N_num/365,eta_P_I_time.*eta_M_I_time,'linewidth',2);
hh = legend('Infeasible region','$\gamma = 0.2$','$\gamma = 0.4$','$\gamma = 0.6$','$\gamma = 0.8$','$\gamma = 1$'); 
ylim([min(eta_P_I_time(end).*eta_M_I_time(end))-0.05 1]);
figure_settings_GFPS('etaPMItime',fontsize,'Time [years]','Total efficiency, \eta_{T} [-]',hh) % name, fontsize, xlabel, ylabel, legends

figure
H = area(X,Y,'LineStyle','-'); H(1).FaceColor = [0 0.2 0.2]; H(1).FaceAlpha = 0.3;
hold all, plot(N_num/365,eta_M_theo_time.*eta_P_theo_time,'linewidth',2);
hh = legend('Infeasible region','$\gamma = 0.2$','$\gamma = 0.4$','$\gamma = 0.6$','$\gamma = 0.8$','$\gamma = 1$'); ylim([min(eta_M_theo_time(end).*eta_P_theo_time(end))-0.05 1])
figure_settings_GFPS('etaPMItime_theo',fontsize,'Time [years]','Total efficiency, \eta_{T} [-]',hh) % name, fontsize, xlabel, ylabel, legends

figure
plot(N_num*const.RPM_M*60*24,chi_aM,'linewidth',2)
hold all
%plot(N_num*const.RPM_M*60*24,chi_dM,'linewidth',2)
hh = legend('$\chi_a$ at $\gamma$ = 0.2','$\chi_a$ at $\gamma$ = 0.4','$\chi_a$ at $\gamma$ = 0.6','$\chi_a$ at $\gamma$ = 0.8','$\chi_a$ at $\gamma$ = 1','$\chi_d$ at $\gamma$ = 0.2','$\chi_d$ at $\gamma$ = 0.4','$\chi_d$ at $\gamma$ = 0.6','$\chi_d$ at $\gamma$ = 0.8','$\chi_d$ at $\gamma$ = 1');
xlim([0 N_num(end)*const.RPM_M*60*24])
figure_settings_GFPS('chitime',fontsize,'Switching cycles, N(t) [-]','Wear propagation function, \chi [-]',hh) % name, fontsize, xlabel, ylabel, legends

%% TIME-DEPENDENT EFFICIENCY WHEN LEAKAGE IS A FUNCTION OF CYCLES
gamma = linspace(0.1,1,25);
t_life_m = 365*24*60*t_life;
clear eta_P_I_time eta_M_I_time
for i = 1:length(gamma)
    for k = 1:length(N_num)
        N_num1 = gamma(i)*N_num(k)/(365)*M_vload;
        N_num2 = gamma(i)*N_num(k)/(365)*P_vload;
        chi_aM(i,k) = alpha*(N_num1/M_vload)^lambda;
        chi_aP = alpha*(N_num2/M_vload)^lambda;
        chi_dM(i,k) = 0.1*(1-exp(-25*N_num1/M_vload));
        chi_dP = 0.1*(1-exp(-25*N_num2/M_vload));
        Q_lM = 1+3*chi_aM(i,k);
        Q_lP = 1+3*chi_aP;
        Q_hM = 1+3*chi_aM(i,k);
        Q_hP = 1+3*chi_aP;
        E_loss_P_lin = interp2(E_loss_P_cycle,Q_hP,Q_lP,'linear');
        E_loss_M_lin = interp2(E_loss_M_cycle,Q_hM,Q_lM,'linear');
        E_loss_PI_lin = interp1(E_loss_cycle_PI,Q_hP,'linear');
        E_loss_I_lin = interp1(E_loss_cycle_I,Q_hM,'linear');
        E_in_P_lin = interp2(E_in_P_cycle,Q_hP,Q_lP,'linear');
        E_in_M_lin = interp2(E_in_M_cycle,Q_hM,Q_lM,'linear');
        eta_P_I_time(k,i) = 1-((E_loss_P_lin)*gamma(i)+(1-gamma(i))*E_loss_PI_lin)/(E_in_P_lin*gamma(i));
        eta_M_I_time(k,i) = 1-((E_loss_M_lin)*gamma(i)+(1-gamma(i))*E_loss_I_lin)/(E_in_M_lin*gamma(i));
        leak_LM = (Q_lM-1)*leak_frac*(Q_rated_M)*const.per_leak_flow;
        leak_HM = (Q_hM-1)*leak_frac*(Q_rated_M)*const.per_leak_flow;
        leak_HP = (Q_hP-1)*leak_frac*(Q_rated_P)*const.per_leak_flow;
        leak_LP = (Q_lP-1)*leak_frac*(Q_rated_P)*const.per_leak_flow;
        eta_M_theo_time(k,i) = func_eta_M(gamma(i),leak_HM,leak_LM);
        eta_P_theo_time(k,i) = func_eta_P(gamma(i),leak_HP,leak_LP);
    end
    Q_leak_mean_M = 0.01*Q_rated_M*alpha*((t_life_m*gamma(i)*const.RPM_M)/M_vload)^lambda/(lambda+1);
    Q_leak_mean_P = 0.01*Q_rated_P*alpha*((t_life_m*gamma(i)*const.RPM)/M_vload)^lambda/(lambda+1);
    eta_mean_cont(i) = func_eta_M(gamma(i),Q_leak_mean_M,Q_leak_mean_M).*func_eta_P(gamma(i),Q_leak_mean_P,Q_leak_mean_P);
end
eta_mean = sum(eta_M_I_time.*eta_P_I_time,1)/length(N_num);
eta_mean_theo = sum(eta_M_theo_time.*eta_P_theo_time,1)/length(N_num);
for i=1:length(gamma)
    eta_mean_noleak(i) = func_eta_M(gamma(i),0,0).*func_eta_P(gamma(i),0,0);
end
peak_stat = find(eta_mean_cont==max(eta_mean_cont));
peak_dyn = find(eta_mean==max(eta_mean));
gamma_opti_stat = gamma(peak_stat(1));
gamma_opti_dyn = gamma(peak_dyn(1));

figure
plot(gamma,eta_mean_cont,gamma,eta_mean,gamma,eta_mean_noleak,'linewidth',2), grid on, hold all
plot([gamma_opti_stat gamma_opti_stat],[0 max(eta_mean_cont)],'k','linestyle','--')
plot([gamma_opti_dyn gamma_opti_dyn],[0 max(eta_mean)],'k','linestyle','-.')
plot([0 gamma_opti_stat],[max(eta_mean_cont) max(eta_mean_cont)],'k','linestyle','--')
plot([0 gamma_opti_dyn],[max(eta_mean) max(eta_mean)],'k','linestyle','-.')
hh = legend('Static','Dynamic','Conventional efficiency curve'); xlim([0 1]), ylim([0.95 1])
figure_settings_GFPS('etamean_gamma',fontsize,'\gamma [-]','Mean \eta_T [-]',hh) % name, fontsize, xlabel, ylabel, legends

fprintf('----------------------- Main dynamics with Leakage V.4 end ------------------------ \n');