Deploy the MAIN folder directly to your C:/ repository (this is important to make all directory paths correct)
Open main.m which is where other scripts may be called. Controlcenter.m allows you to pick the script you want to run. Set call.leakage_study = 1. Press run. 

This initiates 'main_leakageV4' and does all the work. After some time the results should be displayed.

Else, just load the data files of the 'LeakageStudy'-folder and run the part of the 'main_leakageV4' that you want to display.

Software prerequisite:
Matlab/Simulink 16.b or newer for data analysis and lumped models (License required)

