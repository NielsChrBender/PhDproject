%%% ------ main center ------ %%%
% This script is used as the main file to run several functions and scripts
% developed during my PhD thesis at Aalborg University Department of Energy
% Technology 15/08-2016 to 15/08-2019.
% Copy-rights belong exclusively to Niels Christian Bender but may be freely used with appropriate referencing 
close all
fprintf('------------------- Main initialized -------------------- \n');
t_tot_start = tic; % SIM START TIME
directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m'))) % use the controlcenter.m to decide control the program
if call.fluidforce
    run(sprintf('%s%s',directory,strcat('Fluidforce\main_fluidforce.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m'))) % use the controlcenter.m to decide control the program
if call.fluidforce_sphere
    run(sprintf('%s%s',directory,strcat('Fluidforce\sphere\ArticlePlot_simpleSphereExample.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.contour
    run(sprintf('%s%s',directory,strcat('Addons\main_contour.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.stiction
    run(sprintf('%s%s',directory,strcat('Stiction\main_stiction.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.squeeze
    run(sprintf('%s%s',directory,strcat('Stiction\main_squeeze.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.CFD
    run(sprintf('%s%s',directory,strcat('CFD\main_CFD.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.FEM
    run(sprintf('%s%s',directory,strcat('FEM\main_FEM.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.lifetime
    run(sprintf('%s%s',directory,strcat('Lifetime\main_lifetime.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.dynamics
    run(sprintf('%s%s',directory,strcat('Dynamic\main_dynamics.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.validation
    run(sprintf('%s%s',directory,strcat('Validation\main_validfluidforce.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.validation_ASME17
    run(sprintf('%s%s',directory,strcat('Validation\main_validfluidforce_ASME17.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.experimental_plot
    run(sprintf('%s%s',directory,strcat('Validation\main_experimental.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.leakage_study
    run(sprintf('%s%s',directory,strcat('LeakageStudy\main_leakageV4.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.single_piston
    run(sprintf('%s%s',directory,strcat('Dynamic\main_single_piston.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.transient_flow || call.open_transient_flow
    run(sprintf('%s%s',directory,strcat('Dynamic\main_single_piston.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.CFD_results
    figures.convergence = 0;
    figures.convergence1 = 1;
    run(sprintf('%s%s',directory,strcat('constants.m')));
    run(sprintf('%s%s',directory,strcat('Dynamic\Fluidplot.m')))
    run(sprintf('%s%s',directory,strcat('Dynamic\LumpedModelFit.m')))
    run(sprintf('%s%s',directory,strcat('CFD\GridIndependence.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.fatigue
    run(sprintf('%s%s',directory,strcat('Lifetime\main_fatigue.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.HALT
    run(sprintf('%s%s',directory,strcat('constants.m')));
    run(sprintf('%s%s',directory,strcat('Lifetime\main_HALT.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.chamber_damping
    run(sprintf('%s%s',directory,strcat('Lifetime\main_end_damping.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.neural_control
    run(sprintf('%s%s',directory,strcat('Lifetime\main_end_damping.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.flow_equi
    run(sprintf('%s%s',directory,strcat('Lifetime\main_flow_equi.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.cushion_eval
    run(sprintf('%s%s',directory,strcat('Cushion\main_cushion_eval.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.IEEE_data
    run(sprintf('%s%s',directory,strcat('constants.m')));
    run(sprintf('%s%s',directory,strcat('CFD\main_CFDandLPM.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.sensitivity_analysis
    run(sprintf('%s%s',directory,strcat('CFD\main_sensitivity.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.DDU_sensitivity_analysis
    run(sprintf('%s%s',directory,strcat('Cushion\main_DDU_sensitivity.m')))
end
%%% end of subroutine %%%

directory = strcat('C:\MAIN\'); % define your directory
run(sprintf('%s%s',directory,strcat('controlcenter.m')))
if call.PMSM_single_piston
    run(sprintf('%s%s',directory,strcat('constants.m')));
    run(sprintf('%s%s',directory,strcat('PMSM\main_PMSMandDDM.m')))
end
%%% end of subroutine %%%

t_tot_end        = toc(t_tot_start); %Stop time
fprintf([datestr(now),' total simulation time: ',num2str(t_tot_end,'%10.1f'),'[s]\n']);
fprintf('----------------------- Main end ------------------------ \n \n');